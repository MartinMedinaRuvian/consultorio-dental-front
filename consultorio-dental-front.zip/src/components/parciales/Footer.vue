<template>
    <div class="footer">
        <p>Seminario Integrador III UFPS, Cúcuta. 2022</p>
    </div>
</template>