<template>
  <div class="text-center">
    <h2 class="text-success">Desarrolladores 👨‍💻</h2>
    <div class="row mt-5">
      <div class="col-md-3">
        <div class="card mb-4 card-nosotros">
          <div class="card-header bg-transparent">
            <img src="../../assets/martin.png" alt="foto-martin" width="140px" height="180px">
          </div>
          <div class="card-body">
            <h5><b>Martin de Jesus</b></h5>
            <p>Código - 1151791</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card mb-4 card-nosotros">
          <div class="card-header bg-transparent">
            <img alt="foto-johnny" width="220px" height="250px">
          </div>
          <div class="card-body">
            <h5><b>Cristian Medina</b></h5>
            <p>Código - 1151847</p>
          </div>
        </div>        
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-header">
            <img alt="foto-andrey" width="200px" height="250px">
          </div>
          <div class="card-body"> 
            <h5><b>Paula Rico</b></h5>
            <p>Código - 1151910</p>
          </div>
        </div>           
      </div>
      <div class="col-md-3">
        <div class="card">
          <div class="card-header">
            <img alt="foto-andrey" width="200px" height="250px">
          </div>
          <div class="card-body"> 
            <h5><b>Daniel</b></h5>
            <p>Código - 1151670</p>
          </div>
        </div>           
      </div>
    </div>

  </div>
</template>
